from setuptools import setup

setup(
    name='examen_modulo',
    version = '1.0',
    description='Evaluación de la unidad 2',
    author='JLMG',
    author_email='jlmg67815@gmail.com',
    url='trello.com/pa',
    py_modules=['examen_modulo']

)