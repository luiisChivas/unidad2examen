def funcionfuerza(L:float,M:float,T:float):
    fuerza = L*M*T**-2
    return fuerza

def funciontrabajo(L:float,M:float,T:float):
    trabajo = (L**2)* M * T**-2
    return trabajo
